import { GoogleGenAI, Chat, GenerateContentResponse, Modality, GroundingChunk } from "@google/genai";
import { ChatMessage } from '../types';
import { decode } from '../utils/helpers';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set. This is required for the application to function.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

let chat: Chat | null = null;

function getChatInstance(): Chat {
  if (!chat) {
    chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: [],
      config: {
        systemInstruction: "You are Spartan, a friendly and expert hospice sales coach. Keep your answers concise and helpful."
      }
    });
  }
  return chat;
}

export async function getChatResponse(message: string): Promise<string> {
  const chatInstance = getChatInstance();
  const result = await chatInstance.sendMessage({ message });
  return result.text;
}

export function resetChat() {
  chat = null;
}

export async function getGroundedResponse(prompt: string, tool: 'search' | 'maps', location?: { latitude: number; longitude: number }): Promise<{text: string, chunks: GroundingChunk[]}> {
  const tools = tool === 'search' ? [{ googleSearch: {} }] : [{ googleMaps: {} }];
  const toolConfig = tool === 'maps' && location ? { retrievalConfig: { latLng: location } } : undefined;
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      tools,
      toolConfig
    }
  });

  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  return { text: response.text, chunks };
}

export async function getComplexResponse(prompt: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: prompt,
    config: {
      thinkingConfig: { thinkingBudget: 32768 }
    }
  });
  return response.text;
}

export async function getQuickResponse(prompt: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });
  return response.text;
}

export async function getTextToSpeech(text: string): Promise<Uint8Array | null> {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say with a clear, professional voice: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (base64Audio) {
    return decode(base64Audio);
  }
  return null;
}