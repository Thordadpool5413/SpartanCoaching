
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveSession, Modality, Blob, LiveServerMessage } from '@google/genai';
import { encode } from '../utils/helpers';
import { MicIcon, StopIcon } from './icons';

interface AudioTranscriberProps {
  onTranscriptionUpdate: (text: string) => void;
  currentNote: string;
}

const AudioTranscriber: React.FC<AudioTranscriberProps> = ({ onTranscriptionUpdate, currentNote }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState<'idle' | 'recording' | 'processing' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const fullTranscriptionRef = useRef<string>('');

  const stopRecording = useCallback(() => {
    if (sessionPromiseRef.current) {
        sessionPromiseRef.current.then(session => session.close());
        sessionPromiseRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }
    if (sourceRef.current) {
        sourceRef.current.disconnect();
        sourceRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close();
    }
    audioContextRef.current = null;

    setIsRecording(false);
    setStatus('idle');
  }, []);

  const startRecording = async () => {
    if (isRecording) return;
    setIsRecording(true);
    setStatus('recording');
    setError(null);
    fullTranscriptionRef.current = currentNote ? currentNote + ' ' : '';
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      sessionPromiseRef.current = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
             audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
             sourceRef.current = audioContextRef.current.createMediaStreamSource(stream);
             scriptProcessorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            
             scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
              const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              if (sessionPromiseRef.current) {
                  sessionPromiseRef.current.then((session) => {
                      session.sendRealtimeInput({ media: pcmBlob });
                  });
              }
            };
            sourceRef.current.connect(scriptProcessorRef.current);
            scriptProcessorRef.current.connect(audioContextRef.current.destination);
          },
          onmessage: (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              fullTranscriptionRef.current += text;
              onTranscriptionUpdate(fullTranscriptionRef.current);
            }
          },
          onerror: (e: ErrorEvent) => {
            console.error('Live API Error:', e);
            setError('An API error occurred. Please try again.');
            stopRecording();
          },
          onclose: (e: CloseEvent) => {
            // This is an expected event on graceful close
          },
        },
        config: {
            inputAudioTranscription: {},
            responseModalities: [Modality.AUDIO], // Required but we won't process audio output
        },
      });

    } catch (err) {
      console.error('Failed to start recording', err);
      setError('Could not access microphone. Please check permissions.');
      setIsRecording(false);
      setStatus('error');
    }
  };


  useEffect(() => {
    // Cleanup on unmount
    return () => {
      stopRecording();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex flex-col items-center gap-4">
      <button
        onClick={isRecording ? stopRecording : startRecording}
        className={`flex items-center justify-center gap-2 px-6 py-3 font-semibold rounded-lg transition-colors focus:outline-none focus:ring-2 ${
          isRecording 
            ? 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-400' 
            : 'bg-green-600 hover:bg-green-700 text-white focus:ring-green-400'
        }`}
      >
        {isRecording ? <StopIcon /> : <MicIcon />}
        <span>{isRecording ? 'Stop Recording' : 'Record Note'}</span>
      </button>
      {status !== 'idle' && (
        <p className="text-sm text-gray-500 dark:text-gray-400">
          {status === 'recording' && 'Listening... Speak now.'}
          {status === 'error' && `Error: ${error}`}
        </p>
      )}
    </div>
  );
};

export default AudioTranscriber;