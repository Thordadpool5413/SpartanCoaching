
export const LS = {
  get<T,>(key: string, fallback: T): T {
    try {
      const value = window.localStorage.getItem(key);
      return value == null ? fallback : JSON.parse(value);
    } catch {
      return fallback;
    }
  },
  set<T,>(key: string, value: T): void {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error("Failed to save to localStorage", e);
    }
  },
  del(key: string): void {
    try {
      window.localStorage.removeItem(key);
    } catch {}
  },
};

export function cleanHash(h: string): string {
  if (!h || h === "#" || h === "#/") return "/";
  const raw = h.replace(/^#+/, "");
  return raw.startsWith("/") ? raw : "/" + raw;
}

export function parseHash(): { path: string; params: URLSearchParams } {
  const h = typeof window !== "undefined" ? window.location.hash : "";
  const c = cleanHash(h);
  const parts = c.split("?");
  const path = parts[0];
  const qs = parts[1] || "";
  const params = new URLSearchParams(qs);
  return { path, params };
}

export function hrefFor(to: string, params?: Record<string, string | number | boolean>): string {
  const path = to.startsWith("/") ? to : "/" + to;
  const qs = params && Object.keys(params).length ? "?" + new URLSearchParams(params as any).toString() : "";
  return "#" + path + qs;
}

// Audio encoding for Live API
export function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Audio decoding for Live API and TTS
export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export async function playAudio(audioData: Uint8Array, sampleRate: number): Promise<void> {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
    const audioBuffer = await decodeAudioData(audioData, audioContext, sampleRate, 1);
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(audioContext.destination);
    source.start();
}
